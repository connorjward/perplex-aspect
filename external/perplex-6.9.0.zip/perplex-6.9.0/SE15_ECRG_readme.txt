The following files are variously tweaked relative to
perp_source_6.8.2, 24-May-2018.

I've introduced:
    EoS 17 - Brosh's model, FactSage variant
             i.e. Brosh's model subject to Saxena &
             Eriksson's, ahem, variant, in which there
             is no factor n in the quasiharmonic 
             contributions
    special model 42 - Saxena & Eriksson's FeS fluid
with input file data in SE15ver.dat and SE15_sol.dat.

I haven't rerun this after manual version control, 
please return to sender if it blows up. This folder
contains comparisons between Saxena & Eriksson's
(2015) figures and Perple_X calcs prior to 
version control.

ecrg 29-May-2018